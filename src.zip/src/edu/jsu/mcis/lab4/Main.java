package edu.jsu.mcis.lab4;

import java.util.ArrayList;
import java.util.Random;

public class Main
{
    public static void main(String[] args)
    {
        int[] dieSet = {4,6,8,10,12,20,100};
        //Create ArrayList for the dies
        ArrayList<Die> dieList = new ArrayList<>(); 
        
        //Create a loop to choose which 5 dies from the 7 to roll at random
        for(int i=0;i<5;i++) 
        {
            Random random = new Random() ;
            int selected_num_of_faces = 1 + random.nextInt(7);
            
            Die die = new Die(dieSet[selected_num_of_faces-1]);
            dieList.add(die); // Add die to dieList
        }

        // Output
        StringBuilder output_from_rolls = new StringBuilder();

        for(int i=0;i<5;i++) // Rolling the 5 dies in dieList
        {
            Die die = dieList.get(i);
            int rollOutput = die.roll(); // Roll Die
            output_from_rolls.append(die); //Append to the output of roll
            if(i!=4) //Append a comma at the end of rolls 1-4
                output_from_rolls.append(", ");
        }
        System.out.println(output_from_rolls); // Output code
    }
}