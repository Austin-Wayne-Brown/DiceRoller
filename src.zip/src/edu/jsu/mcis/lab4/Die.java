package edu.jsu.mcis.lab4;

import java.util.Random;

public class Die
{   //Instance Fields
    
    private int numFaces;
    private int faceValue;

    // Constructor
    
    Die(int numFaces)
    {
        this.numFaces = numFaces;
    }
    
    //Methods
    
   public int roll()
    {
        Random random = new Random();
        faceValue = 1 + random.nextInt(numFaces);
        return faceValue; // return the face value
    }
   
    public int getFaceValue()
    {
        return  faceValue; // return the face value
    }

    public int getNumFaces() 
    {
        return numFaces;
    }

    @Override
    public String toString() 
    {
        return "d" + numFaces + " = " + faceValue;
    }
}
